using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BakeryInventorySystem.Models;

namespace BakeryInventorySystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly BakeryDbContext _context;

        public HomeController(BakeryDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var totalProducts = await _context.Products.CountAsync();
            var totalCategories = await _context.Categories.CountAsync();
            var lowStock = await _context.Products.CountAsync(p => p.Quantity < 5);
            var expired = await _context.Products.CountAsync(p => p.ExpiryDate < DateTime.Now);

            ViewBag.TotalProducts = totalProducts;
            ViewBag.TotalCategories = totalCategories;
            ViewBag.LowStock = lowStock;
            ViewBag.Expired = expired;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
