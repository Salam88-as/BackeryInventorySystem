﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BakeryInventorySystem.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Product Name")]
        public string Name { get; set; } = string.Empty;

        public int Quantity { get; set; }

        [DataType(DataType.Currency)]
        public decimal Price { get; set; }

        [Display(Name = "Manufacture Date")]
        [DataType(DataType.Date)]
        public DateTime MfgDate { get; set; }

        [Display(Name = "Expiry Date")]
        [DataType(DataType.Date)]
        public DateTime ExpiryDate { get; set; }

        [Display(Name = "Ingredients")]
        public string? Ingredients { get; set; } // 🆕 Optional field

        [Display(Name = "Product Image")]
        public string? ImagePath { get; set; }   // 🆕 Image URL

        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        public Category? Category { get; set; }
    }
}
